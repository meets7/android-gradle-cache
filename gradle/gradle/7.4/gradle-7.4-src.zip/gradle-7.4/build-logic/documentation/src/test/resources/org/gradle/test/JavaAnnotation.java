package org.gradle.test;

public @interface JavaAnnotation {
}
